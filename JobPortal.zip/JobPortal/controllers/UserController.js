import User from "../models/User.js";
export const UserRegister = async (request, response, next) => {
  try {
    const { name, email, password } = request.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      const error = new Error("User Already Registered");
      error.status = 400;
      return next(error);
    }
    const user = await User.create({ name, email, password });
    const token = user.createJWT();
    return response.status(200).send({
      success: true,
      message: "User Created Successfully",
      userData: user,
      token,
    });
  } catch (error) {
    next(new Error("User Registration Error!"));
  }
};

export const UserLogin = async (request, response, next) => {
  const { email, password } = request.body;
  const user = await User.findOne({email});
  if(user){
    const isPasswordMatched = await user.comparePassword(password);
    if(isPasswordMatched){
      const token = user.createJWT();
      return response.status(200).send({
        status: true,
        message: "Logged In Successfully",
        userData: user,
        token,
      })
    }
  }
  const error = new Error("Invalid Email Or Password");
  error.status = 404;
  return next(error);
};

export const UserDashboard = (request, response)=>{
  return response.status(200).send("Dashboard");
}

export const UserUpdate = async (request, response, next) => {
  const {name, email, password} = request.body;
  if(!name || !email || !password){
    const error = new Error("All Required Fields Must Be Filled");
    error.status = 400;
    return next(error);
  }
  const user = await User.findOne({_id : request.user.userId});
  if(user){
    user.name = name;
    user.email = email;
    user.password = password;

    await user.save();
    const token = user.createJWT();
    return response.status(200).send({
      userData: user,
      token,
      success: true,
      message: "User Data Updated Successfully"
    });
  }
}