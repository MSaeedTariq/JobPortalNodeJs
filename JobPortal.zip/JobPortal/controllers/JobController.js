import Job from "../models/Job.js";
import mongoose from "mongoose";
import moment from "moment";
export const jobCreate = async (request, response, next) => {
  const { company, position } = request.body;
  if (!company || !position) {
    const error = new Error("All Required Fields Must Be Filled");
    error.status = 400;
    return next(error);
  }
  request.body.createdBy = request.user.userId;
  const job = await Job.create(request.body);
  return response.status(200).send({
    status: true,
    jobData: job,
  });
};

export const jobGetAll = async (request, response) => {
  const { status, workType, search, sort } = request.query;
  const queryObject = {
    createdBy: request.user.userId,
  };
  if (status && status !== "all") {
    // not a db value but only comming from fornt end if user selects all the types
    queryObject.status = status;
  }
  if (workType && workType !== "all") {
    // not a db value but only comming from fornt end if user selects all the types
    queryObject.workType = workType;
  }
  if (search) {
    queryObject.position = { $regex: search, $options: "i" };
  }
  let queryResult = Job.find(queryObject);

  if (sort) {
    if (sort === "latest") {
      queryResult = queryResult.sort("-createdAt");
    } else if (sort === "oldest") {
      queryResult = queryResult.sort("createdAt");
    } else if (sort === "a-z") {
      queryResult = queryResult.sort("position");
    } else if (sort === "z-a") {
      queryResult = queryResult.sort("-position");
    }
  }

  const page = Number(request.query.page) || 1;
  const limit = Number(request.query.limit) || 10;
  const skip = (page - 1) * limit;
  queryResult = queryResult.skip(skip).limit(limit);
  const jobCount = await Job.countDocuments(queryResult);
  const totalPageNumber = Math.ceil(jobCount / limit);
  const jobs = await queryResult;
  // const jobs = await Job.find({ createdBy: request.user.userId });
  return response.status(200).send({
    success: true,
    jobCount: jobCount,
    JobData: jobs,
    totalPageNumber: totalPageNumber,
  });
};

export const jobUpdate = async (request, response, next) => {
  const { id } = request.params;
  const { company, position } = request.body;
  if (!company || !position) {
    const error = new Error("All Required Fields Must Be Filled");
    error.status = 400;
    return next(error);
  }
  const job = await Job.findOne({ _id: id });
  if (job && request.user.userId === job.createdBy.toString()) {
    const job = await Job.findOneAndUpdate({ _id: id }, request.body, {
      new: true,
      runValidators: true,
    });
    return response.status(200).send({
      success: true,
      jobData: job,
      message: "Job Updated Successfully",
    });
  }
  const error = new Error("Error! Job Not Found");
  error.status = 404;
  return next(error);
};

export const jobDelete = async (request, response, next) => {
  const { id } = request.params;
  const job = await Job.findOne({ _id: id });
  if (job && request.user.userId === job.createdBy.toString()) {
    await Job.findOneAndDelete({ _id: id });
    return response.status(200).send({
      success: true,
      message: "Job Deleted Successfully",
    });
  }
  const error = new Error("Error! Job Not Found");
  error.status = 404;
  return next(error);
};

export const jobStats = async (request, response) => {
  const stats = await Job.aggregate([
    {
      $match: {
        createdBy: new mongoose.Types.ObjectId(request.user.userId),
      },
    },
    {
      $group: {
        _id: "$status",
        count: { $sum: 1 },
      },
    },
  ]);

  const defaultStats = {
    pending: 0,
    reject: 0,
    interview: 0,
  };
  stats.forEach((stat) => {
    if (stat._id === "pending") {
      defaultStats.pending = stat.count;
    } else if (stat._id === "reject") {
      defaultStats.reject = stat.count;
    } else if (stat._id === "interview") {
      defaultStats.interview = stat.count;
    }
  });

  let yearlyAndMonthlyStats = await Job.aggregate([
    {
      $match: {
        createdBy: new mongoose.Types.ObjectId(request.user.userId),
      },
    },
    {
      $group: {
        _id: {
          year: { $year: "$createdAt" },
          month: { $month: "$createdAt" },
        },
        count: {
          $sum: 1,
        },
      },
    },
  ]);

  yearlyAndMonthlyStats = yearlyAndMonthlyStats
    .map((item) => {
      const {
        _id: { year, month },
        count,
      } = item;
      const date = moment()
        .month(month - 1)
        .year(year)
        .format("MMM y");
      return { date, count };
    })
    .reverse();
  response.status(200).send({
    totalJobs: stats.length,
    statsData: defaultStats,
    yearlyAndMonthlyStats: yearlyAndMonthlyStats,
  });
};
