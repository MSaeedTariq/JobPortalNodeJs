import mongoose from "mongoose";

const DbConnection = async()=>{
    try {
        await mongoose.connect(process.env.MONGO_DB_URL);
        console.log(`Database Connected Successfully! ${mongoose.connection.host}`);
    } catch (error) {
        console.log(`MongoDb Error! ${error}`);
    }
}

export default DbConnection;