import mongoose from "mongoose";
import validator from "validator";
const userSchema = new mongoose.Schema({

    name:{
        type:String,
        required:[true, "Name Is Required"]
    },
    lastName:{
        type:String,
    },
    email:{
        type:String,
        required:[true, "Email Is Required"],
        unique: true,
        validate: validator.isEmail
    },
    password:{
        type:String,
        required:[true, "Password Is Required"]
    },
    location:{
        type:String,
        default: "Pakistan"
    },

}, {timestamps: true});

export default mongoose.model('User' , userSchema);