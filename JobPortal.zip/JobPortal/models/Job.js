import mongoose from "mongoose";
const jobSchema = mongoose.Schema(
  {
    company: {
      type: String,
      required: [true, "Company Is Required"],
    },
    position: {
      type: String,
      required: [true, "Position Is Required"],
    },
    status: {
      type: String,
      enum: ["pending", "reject", "interview"],
      default: "pending",
    },
    workType: {
      type: String,
      enum: ["full-time", "part-time", "internship", "contract"],
      default: "full-time",
    },
    workLocation: {
      type: String,
      default: "Lahore",
      required: [true],
    },
    createdBy: {
      type: mongoose.Types.ObjectId,
      ref: "User",
    },
  },
  { timestamps: true }
);
export default mongoose.model("Job", jobSchema);
