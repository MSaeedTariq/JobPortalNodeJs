import express from "express";
import dotenv from "dotenv";
import cors from 'cors';
import morgan from "morgan";
import DbConnection from "./config/db.js";
import userRoutes from './routes/userRoutes.js';
import errorMiddleware from "./middlewares/errorMiddleware.js";

dotenv.config();
DbConnection();


const app = express();
const port  = process.env.PORT || 8000;

app.use(express.json());
app.use(cors());
app.use(morgan("dev"));

app.use('/api/v1/user' , userRoutes);

app.use(errorMiddleware);

app.listen(port  ,()=>{
    console.log(`Server Running On Port ${port}`);
})