import express from "express";
import dotenv from "dotenv";
import swaggerJSDoc from "swagger-jsdoc";
import swaggerUI from "swagger-ui-express";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import xss from "xss-clean";
import mongoSanitize from "express-mongo-sanitize";
import DbConnection from "./config/db.js";
import userRoutes from "./routes/userRoutes.js";
import jobRoutes from "./routes/jobRoutes.js";
import errorMiddleware from "./middlewares/errorMiddleware.js";

dotenv.config();
DbConnection();

const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "JobPortalApplication",
      description: "NodeJs Project",
    },
    servers: [
      {
        url: "http://localhost:8000",
      },
    ],
  },
  apis: ["./routes/*.js"],
};

const sepcs = swaggerJSDoc(options);


const app = express();
const port = process.env.PORT || 8000;

app.use(helmet());
app.use(xss());
app.use(mongoSanitize());
app.use(express.json());
app.use(cors());
app.use(morgan("dev"));

app.use("/api/v1/user", userRoutes);
app.use("/api/v1/job", jobRoutes);
app.use("/api-doc", swaggerUI.serve , swaggerUI.setup(sepcs));

app.use(errorMiddleware);

app.listen(port, () => {
  console.log(`Server Running On Port ${port}`);
});
