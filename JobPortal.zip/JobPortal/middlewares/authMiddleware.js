import JWT from "jsonwebtoken";
const userAuth = async (request, response, next) => {
  const header = request.headers.authorization;
  if (header && header.startsWith("Bearer")) {
    const token = header.split(" ")[1];
    const payload = JWT.verify(token, process.env.JWT_SECRET);
    request.user = { userId: payload.userId };
    next();
  } else {
    const error = new Error("UnAuthorized Access");
    error.status = 401;
    return next(error);
  }
};

export default userAuth;
