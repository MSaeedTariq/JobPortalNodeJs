const errorMiddleware = (error, request, response, next) => {
  console.log("Error!", error);
  const defaultErrors = {
    statusCode: 500,
    message: error.message || "Something went wrong",
  };

  if (error.name === "ValidationError") {
    defaultErrors.statusCode = 400;
    defaultErrors.message = Object.values(error.errors)
      .map((item) => item.message)
      .join(",");
  }

  if(error.code && error.code === 11000){
    defaultErrors.statusCode = 400;
    defaultErrors.message = `${Object.keys(error.keyValue)} has to be unique`;
  }

  response
    .status(defaultErrors.statusCode)
    .json({ message: defaultErrors.message });
};

export default errorMiddleware;
