import express from "express";
import { UserRegister, UserLogin, UserDashboard, UserUpdate } from "../controllers/UserController.js";
import userAuth from "../middlewares/authMiddleware.js";

const router = express.Router();

router.post("/register", UserRegister);
router.post("/login" , UserLogin);
router.get("/dashboard" , userAuth, UserDashboard);
router.post("/update" , userAuth, UserUpdate);

export default router;
