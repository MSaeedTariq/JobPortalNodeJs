import express from "express";
import userAuth from "../middlewares/authMiddleware.js";
import rateLimiter from "../middlewares/rateLimiterMiddleware.js";
import {
  jobCreate,
  jobGetAll,
  jobUpdate,
  jobDelete,
  jobStats,
} from "../controllers/JobController.js";
const router = express.Router();

router.post("/create", userAuth, rateLimiter, jobCreate);
router.get("/", userAuth, rateLimiter, jobGetAll);
router.patch("/update/:id", userAuth, rateLimiter, jobUpdate);
router.delete("/delete/:id", userAuth, rateLimiter, jobDelete);
router.get("/stats", userAuth, rateLimiter, jobStats);
export default router;
